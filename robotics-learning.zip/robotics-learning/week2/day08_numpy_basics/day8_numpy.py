"""Day 8: NumPy arrays, indexing, slicing, broadcasting."""
import numpy as np


def exercise_1():
    a = np.arange(1, 21)
    print("1) Even numbers:", a[a % 2 == 0])


def exercise_2():
    m = np.arange(16).reshape(4, 4)
    print("2) Second column:", m[:, 1])
    print("   Last row:", m[-1, :])
    print("   Bottom-right 2x2:\n", m[2:, 2:])


def exercise_3():
    m = np.array([[1.0, 2.0, 3.0],
                  [4.0, 5.0, 9.0],
                  [7.0, 8.0, 6.0]])
    centered = m - m.mean(axis=0)  # broadcasting: (3,3) - (3,)
    print("3) Centered:\n", centered)
    print("   Column means after centering:", centered.mean(axis=0))


def exercise_4():
    deg = np.array([0, 30, 45, 60, 90])
    rad = np.radians(deg)
    print("4) Radians:", rad)
    print("   Sines:", np.round(np.sin(rad), 4))


def exercise_5():
    i5 = np.eye(5)
    i5[2, 2] = 7
    print("5) Modified identity:\n", i5)


def view_vs_copy():
    a = np.array([1, 2, 3, 4])
    view = a[:2]
    view[0] = 99
    print("View changes the original:", a)
    b = np.array([1, 2, 3, 4])
    cp = b[:2].copy()
    cp[0] = 99
    print("Copy does not:", b)


def broadcasting_demo():
    m = np.array([[1, 2, 3], [4, 5, 6]])
    print("m + row:\n", m + np.array([10, 20, 30]))
    print("m + col:\n", m + np.array([[100], [200]]))
    print("sum axis=0:", m.sum(axis=0), "axis=1:", m.sum(axis=1))


if __name__ == "__main__":
    exercise_1()
    exercise_2()
    exercise_3()
    exercise_4()
    exercise_5()
    view_vs_copy()
    broadcasting_demo()
