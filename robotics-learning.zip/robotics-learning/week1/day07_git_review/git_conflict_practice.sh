#!/usr/bin/env bash
# Day 7: create a merge conflict on purpose, then resolve it by hand.
# Run in an empty folder:  bash git_conflict_practice.sh
set -e

mkdir -p git-practice && cd git-practice
git init -q -b main
echo "speed = 50" > config.py
git add . && git commit -qm "Add config"

git switch -qc fast
echo "speed = 150" > config.py
git commit -qam "Set speed to 150"

git switch -q main
echo "speed = 100" > config.py
git commit -qam "Set speed to 100"

# This merge conflicts. Edit config.py, keep "speed = 120", then:
#   git add config.py && git commit -m "Resolve conflict"
git merge fast || echo ">> Conflict created. Open config.py and resolve it."
