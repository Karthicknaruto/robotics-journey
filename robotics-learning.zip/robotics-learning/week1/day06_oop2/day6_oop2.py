"""Day 6 (block 1): inheritance, polymorphism and dunder methods."""
import math


# ---- Inheritance, super(), overriding, polymorphism ----
class RobotBase:
    def __init__(self, name):
        self.name = name

    def describe(self):
        return f"I am {self.name}"


class ArmRobot(RobotBase):
    def __init__(self, name, joints):
        super().__init__(name)
        self.joints = joints


class MobileRobot(RobotBase):
    def describe(self):  # overrides the parent method
        return f"I am {self.name}, a mobile robot"


# ---- Dunder methods / operator overloading ----
class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __add__(self, other):
        return Vector(self.x + other.x, self.y + other.y)

    def __sub__(self, other):
        return Vector(self.x - other.x, self.y - other.y)

    def __mul__(self, k):
        return Vector(self.x * k, self.y * k)

    def __eq__(self, other):
        return self.x == other.x and self.y == other.y

    def __repr__(self):
        return f"Vector({self.x}, {self.y})"


# ---- Practice: Shape polymorphism ----
class Shape:
    def area(self):
        raise NotImplementedError


class Circle(Shape):
    def __init__(self, r):
        self.r = r

    def area(self):
        return math.pi * self.r ** 2


class Rectangle(Shape):
    def __init__(self, w, h):
        self.w = w
        self.h = h

    def area(self):
        return self.w * self.h


# ---- Practice: __len__ ----
class Path:
    def __init__(self, points):
        self.points = list(points)

    def __len__(self):
        return len(self.points)


if __name__ == "__main__":
    robots = [RobotBase("A"), ArmRobot("B", 6), MobileRobot("C")]
    for r in robots:
        print(r.describe())
    print(isinstance(robots[1], RobotBase))   # True

    v1, v2 = Vector(1, 2), Vector(3, 4)
    print(v1 + v2, v2 - v1, v1 * 3, v1 == Vector(1, 2))

    for s in [Circle(1), Rectangle(2, 3)]:
        print(type(s).__name__, round(s.area(), 3))

    print(len(Path([(0, 0), (1, 1), (2, 2)])))   # 3
