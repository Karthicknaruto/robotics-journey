# Robot class

A small 2D mobile robot model: position, heading, `move()`, `turn()` and a path history.

## Run

```bash
python3 robot.py
```

Example output:

```
Robot(Bot-1, x=5.00, y=3.00, heading=90)
Distance travelled: 8.0
```

## Features

- `move(distance)` moves forward along the heading
- `turn(angle_deg)` rotates counterclockwise
- `distance_travelled()` sums the path length
- `ArmRobot` subclass with joint angles
- `__eq__` compares robots by position
