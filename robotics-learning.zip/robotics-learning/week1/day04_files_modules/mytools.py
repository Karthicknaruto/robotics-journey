"""Small reusable helpers (a custom module)."""
import math


def deg_to_rad(deg):
    return deg * math.pi / 180


def mm_to_m(mm):
    return mm / 1000
