"""Day 4: read a CSV and print simple statistics."""
import csv
import os
from statistics import mean, median, stdev

HERE = os.path.dirname(os.path.abspath(__file__))


def load_column(filename, column):
    """Read one numeric column from a CSV file."""
    values = []
    with open(filename) as f:
        reader = csv.DictReader(f)
        for row in reader:
            values.append(float(row[column]))
    return values


def print_stats(name, values):
    print(f"{name}: count={len(values)}, min={min(values)}, max={max(values)}, "
          f"mean={mean(values):.2f}, median={median(values):.2f}, "
          f"std={stdev(values):.2f}")


if __name__ == "__main__":
    path = os.path.join(HERE, "data.csv")
    for col in ["angle_deg", "torque_nm"]:
        print_stats(col, load_column(path, col))
