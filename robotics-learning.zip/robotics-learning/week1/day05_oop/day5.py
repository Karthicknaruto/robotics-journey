"""Day 5: classes, __init__, methods. Point and Vector."""
import math


class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distance_to(self, other):
        return math.sqrt((self.x - other.x) ** 2 + (self.y - other.y) ** 2)

    def midpoint(self, other):
        return Point((self.x + other.x) / 2, (self.y + other.y) / 2)

    def __repr__(self):
        return f"Point({self.x}, {self.y})"


class Vector:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def magnitude(self):
        return math.sqrt(self.x ** 2 + self.y ** 2)

    def dot(self, other):
        return self.x * other.x + self.y * other.y

    def scale(self, k):
        return Vector(self.x * k, self.y * k)

    def __repr__(self):
        return f"Vector({self.x}, {self.y})"


class Robot:
    def __init__(self, name):
        self.name = name
        self.x = 0
        self.y = 0

    def move(self, dx, dy):
        self.x += dx
        self.y += dy

    def __repr__(self):
        return f"Robot({self.name}, x={self.x}, y={self.y})"


if __name__ == "__main__":
    p1, p2 = Point(0, 0), Point(3, 4)
    print(p1.distance_to(p2))        # 5.0
    print(p1.midpoint(p2))           # Point(1.5, 2.0)

    v = Vector(3, 4)
    print(v.magnitude())             # 5.0
    print(v.dot(Vector(1, 0)))       # 3
    print(v.scale(2))                # Vector(6, 8)

    a, b = Robot("A"), Robot("B")
    a.move(1, 2)
    b.move(5, 5)
    print(a, b)                      # each keeps its own data
