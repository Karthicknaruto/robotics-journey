# Robotics to Physical AI: Learning Log

Code from my 26-week robotics learning plan (Python, NumPy, kinematics, ROS2, motion planning, vision, RL).

## Contents

| Folder | Topic |
|---|---|
| `week1/day03_collections` | Lists, tuples, dicts, sets, comprehensions |
| `week1/day04_files_modules` | File handling, CSV, modules, CSV statistics script |
| `week1/day05_oop` | Classes, `__init__`, methods: Point and Vector |
| `week1/day06_oop2` | Inheritance, dunder methods, Robot class mini project |
| `week1/day07_git_review` | Git branch/merge/conflict practice script, weekly review |
| `week2/day08_numpy_basics` | NumPy arrays, indexing, slicing, broadcasting |

## Setup

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```

## Run

```bash
python3 week1/day03_collections/day3.py
cd week1/day04_files_modules && python3 stats.py && cd ../..
python3 week1/day05_oop/day5.py
python3 week1/day06_oop2/day6_oop2.py
python3 week1/day06_oop2/robot.py
python3 week2/day08_numpy_basics/day8_numpy.py
```
